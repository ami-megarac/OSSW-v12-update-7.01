#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SDBusCpp::sdbus-c++" for configuration "None"
set_property(TARGET SDBusCpp::sdbus-c++ APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(SDBusCpp::sdbus-c++ PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabi/libsdbus-c++.so.1.2.0"
  IMPORTED_SONAME_NONE "libsdbus-c++.so.1"
  )

list(APPEND _cmake_import_check_targets SDBusCpp::sdbus-c++ )
list(APPEND _cmake_import_check_files_for_SDBusCpp::sdbus-c++ "${_IMPORT_PREFIX}/lib/arm-linux-gnueabi/libsdbus-c++.so.1.2.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
