#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/lib/arm-linux-gnueabi"
XML2_LIBS="-lxml2 -lz  -llzma    -licui18n -licuuc -licudata  -lm "
XML2_INCLUDEDIR="-I/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.14"

