# Code status:

* [![Appveyor CI status](https://ci.appveyor.com/api/projects/status/4u6pexmtpuf8jq66?svg=true)](https://ci.appveyor.com/project/rasmushoj/server) ci.appveyor.com

## MariaDB: The innovative open source database

MariaDB was designed as a drop-in replacement of MySQL(R) with more
features, new storage engines, fewer bugs, and better performance.

MariaDB is brought to you by the MariaDB Foundation and the MariaDB Corporation.
Please read the CREDITS file for details about the MariaDB Foundation,
and who is developing MariaDB.

MariaDB is developed by many of the original developers of MySQL who
now work for the MariaDB Corporation, the MariaDB Foundation and by
many people in the community.

MySQL, which is the base of MariaDB, is a product and trademark of Oracle
Corporation, Inc. For a list of developers and other contributors,
see the Credits appendix.  You can also run 'SHOW authors' to get a
list of active contributors.

A description of the MariaDB project and a manual can be found at:

https://mariadb.org

https://mariadb.com/docs/

https://mariadb.com/docs/release-notes/community-server/about/compatibility-and-differences/mariadb-vs-mysql-features

https://mariadb.com/docs/release-notes/community-server/about/compatibility-and-differences/mariadb-vs-mysql-compatibility

https://mariadb.com/docs/release-notes

# Getting the code, building it and testing it

Refer to the following guide: https://mariadb.org/get-involved/getting-started-for-developers/get-code-build-test/
which outlines how to build the source code correctly and run the MariaDB testing framework,
as well as which branch to target for your contributions.

# Help

More help is available from the Maria Discuss mailing list
https://lists.mariadb.org/postorius/lists/discuss.lists.mariadb.org/ and MariaDB's Zulip
instance, https://mariadb.zulipchat.com/

# Licensing

***************************************************************************

MariaDB is specifically available only under version 2 of the GNU
General Public License (GPLv2). (I.e. Without the "any later version"
clause.) This is inherited from MySQL. Please see the README file in
the MySQL distribution for more information.

License information can be found in the COPYING file. Third party
license information can be found in the THIRDPARTY file.

***************************************************************************

# Bug Reports

Bug and/or error reports regarding MariaDB should be submitted at:
https://jira.mariadb.org

For reporting security vulnerabilities see:
https://mariadb.org/about/security-policy/

The code for MariaDB, including all revision history, can be found at:
https://github.com/MariaDB/server
